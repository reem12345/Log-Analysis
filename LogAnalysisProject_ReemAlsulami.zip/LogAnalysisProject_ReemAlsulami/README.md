LOG ANALYSIS PROJECT
This project for Udacity's Full Stack Web Developer Nanodegree. And it aim is create a reporting tool 
that prints out reports (in plain text) based on the data in the database. This reporting tool is a Python program using 
the psycopg2 module to connect to the database.

GITTING STARTED
To start on this project, you'll need database software (provided by a Linux virtual machine) and the data to analyze.
and you can use the PostgreSQL database and support software needed to complete this project.

PREREQUISITES
1) Complete the databases with SQL and python lessons in Udacity's Full Stack Web Developer Nanodegree.
2) The news database from Udacity's Full Stack Web Developer Nanodegree.
3) Virtual Box Software.
4) vagrant software.
5) Python 3 
6) connect to database using psycopg2 Python module.

INSTALLING
1) Install VirtualBox Software:
VirtualBox is the software that actually runs the virtual machine.
Install the platform package for your operating system. You do not need the extension pack or the SDK. You do not need to launch VirtualBox after installing it; Vagrant will do that. Currently (October 2017), the supported version of VirtualBox to install is version 5.1. Newer versions do not work with the current release of Vagrant.

2) Install Vagrant Software:
Vagrant is the software that configures the VM and lets you share files between your host computer and the VM's filesystem.

3) Download the VM configuration:
There are a couple of different ways you can download the VM configuration.
You can download and unzip this file: FSND-Virtual-Machine.zip This will give you a directory called FSND-Virtual-Machine. It may be located inside your Downloads folder.
Alternately, you can use Github to fork and clone the repository https://github.com/udacity/fullstack-nanodegree-vm.
Either way, you will end up with a new directory containing the VM files. 

4) Download the data:
download the data file from project description in databases with SQL and python lessons in Udacity's Full Stack Web Developer Nanodegree. The file inside is called newsdata.sql. Put this file into the vagrant directory, which is shared with your virtual machine.
To load the data, cd into the vagrant directory and use the command psql -d news -f newsdata.sql.

RUNNING THE TESTS:
1) using terminal cd into the project directory.
2) then, cd into vagrant directory.
3) run "vagrant up" then "vagrant ssh" command.
4) run the python file using this command:
vagrant@vagrant:~$ cd /vagrant
vagrant@vagrant:/vagrant$ python newsdb.py

Output:
The most popular three articles of all time:
Candidate is jerk, alleges rival :  338647 Views
Bears love berries, alleges bear :  253801 Views
Bad things gone, say good people :  170098 Views

The most popular article authors of all time:
Ursula La Multa :  507594 Views
Rudolf von Treppenwitz :  423457 Views
Anonymous Contributor :  170098 Views
Markoff Chaney :  84557 Views

The day have more than 1% of requests lead to errors:
2016-07-17 :  2.3 %

the third query implement using two views:
create view errors as select date(time),count(*) as error from log where status = '404 NOT FOUND' group by date(time);

create view requests as select date(time),count(*) as error from log group by date(time);



Author:
Reem Abdulmoti Alsulami - CS Student.

Resourses:
I use replace method in sql in the first query
https://stackoverflow.com/questions/45471366/how-would-i-join-two-tables-a-and-b-on-a-slug-and-b-path-in-postgresql




