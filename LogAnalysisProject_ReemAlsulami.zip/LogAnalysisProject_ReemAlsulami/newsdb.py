import psycopg2

DBNAME = "news"


def get_Articals():
    """Return the most popular three articles of all time."""
    db = psycopg2.connect(database=DBNAME)
    c = db.cursor()
    c.execute("""select title,count(*) as views from articles ,log
    where replace(log.path, '/article/', '') = articles.slug
    group by articles.title
    order by views desc
    limit 3""")
    articals = c.fetchall()
    db.close()
    return articals


def get_Authors():
    """Return the most popular article authors of all time."""
    db = psycopg2.connect(database=DBNAME)
    c = db.cursor()
    c.execute("""select name,count(*) as views from articles,log,authors
    where articles.author = authors.id and
    (replace(log.path, '/article/', '') = articles.slug)
    group by authors.name
    order by views desc""")
    authors = c.fetchall()
    db.close()
    return authors


def get_Errors():
    """Return the most popular article authors of all time."""
    db = psycopg2.connect(database=DBNAME)
    c = db.cursor()
    c.execute("""select requests.date, round((100.0 * errors.error/requests.error),1)
    as per from errors,
    requests where errors.date = requests.date order by per desc limit 1""")
    errors = c.fetchall()
    db.close()
    return errors


print "The most popular three articles of all time:"
for row in get_Articals():
    print row[0], ": ", row[1], "Views"


print " "
print "The most popular article authors of all time:"

for row in get_Authors():
    print row[0], ": ", row[1], "Views"

print " "
print "The day have more than 1% of requests lead to errors:"

for row in get_Errors():
    print row[0], ": ", row[1], "%"

